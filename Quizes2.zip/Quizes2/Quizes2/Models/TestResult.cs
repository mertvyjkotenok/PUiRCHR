﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Quizes2.Models
{
    internal class TestResult
    {
        public int MinScore { get; set; }
        public int MaxScore { get; set; }
        public string Text { get; set; }
    }
}
